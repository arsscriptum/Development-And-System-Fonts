FREECAM v2 is a public domain font created by Michelle Lyons. It is intended to be used to emulate the in-camera titling facilities of early consumer video cameras.

It was originally produced in response to a free camcorder font being withdrawn and only being made available under a non-commercial license - that you had to pay for (?!). Five minutes worth of Googling came up with a full NTSC resolution screengrab of a complete camcorder font, and FreeCam v1 was created.

Version 1 only had alphanumeric characters, but Version 2 includes some of the most commonly-used punctuation marks, like exclamation marks, question marks, colons, semi-colons and a few other things. As this font is public domain, it may be used by anyone for any purpose, including commercial ones. Editing of the font is also allowed.

This font was publically re-released on 19th January 2022.