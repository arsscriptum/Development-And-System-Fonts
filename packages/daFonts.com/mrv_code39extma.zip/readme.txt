Morovia Free Code39 Full ASCII Font
==================

Date: January 2010

This is not a demo font. This is a full working version of typeface 
"MRV Code39ExtMA" produced by Morovia Corporation (http://www.morovia.com).
It is able to produce extended code39 barcodes for letters, numbers and 
punctuation symbols.

For a complete set of Morovia Code39 Full ASCII Font, visit 
http://www.morovia.com/font/.