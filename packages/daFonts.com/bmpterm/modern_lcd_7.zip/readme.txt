
True Type Font: Modern LCD-7 version 1.0


EULA
-==-
The fonts Modern LCD-7 is freeware for home using only.


DESCRIPTION
-=========-
Original LCD font like seven-segment clock faces. Native size is 15 points. Only Cyrillic code page is supported.

Files in modern_lcd-7.zip:
       	readme.txt     			this file;
        modern_lcd-7.ttf    		regular font;
	modern_lcd-7_screen.png		preview image.

Please visit http://www.styleseven.com/ for download our other products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


FREEWARE USE (NOTES)
-==================-
Also you may: 
 * Use the font in freeware software (credit needed);
 * Use the font for your education process.


COMMERCIAL OR BUSINESS USE
-========================-
Please contact us ($24.95).
You may:
 * Include the font to your installation;
 * Use one license up to 100 computers in your office.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: January 16 2013