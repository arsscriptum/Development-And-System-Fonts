I used FontStruct to build this font. Please visit my page on the site to check for any updates on my fonts:

http://fontstruct.fontshop.com/fontstructors/metroid345/public

Thank you for downloading my font. In this ZIP File, there should be a True-Type-Font file, this readme-txt file, a readme-txt file from fontstruct.fontshop.com, and a license-txt file from fontstruct.fontshop.com. Here is a summary of the license you must abide to use this font (taken from fontstruct.fontshop.com):

Creative Commons Attribution Non-commercial Share Alike

"This license lets others remix, tweak, and build upon [this] work non-commercially, as long as they credit [the original creator] and license their new creations under the identical terms. All new work based on [this] will carry the same license, so any derivatives will also be non-commercial in nature."

The True-Type-Fonts is:

MMBNThick

========NOTE========

-----MMBNThick------
The thick font from the Megaman:BN games. This was the font used in the Folders and Library Menus.

Letters I didn't see while playing the game, (so I essentially improvised, and made my own):

X (upper-case)
j, z (both lower-case)

Every letter from the Latin alphabet (A-Z) uppercase and lowercase, and all numbers (0-9) are available.

For the * (asterisk): press = (equal sign)
For + (plus sign): press + (plus sign)
For mini-slash: press / (solidus)

For MINI numbers (0-9):

0: ) (right parenthesis)
1: ! (exclamation mark)
2: @ (commercial art)
3: # (number sign)
4: $ (dollar sign)
5: % (percent sign)
6: ^ (circumflex accent)
7: & (ampersand)
8: * (asterisk)
9: ( (left parenthesis)

The MB, SP, and EX symbols are:

MB: ' (apostrophe)
SP: : (colon)
EX: ; (semicolon)

To render this font in the same size as it is in the video game (so that it doesn't get distorted), make sure it is in these sizes (or any multiple of these sizes):
-Internet (default): 1em, 16px, 12pt, 100%
-Paint: 10 (whatever the unit is in Paint)
-GIMP (and probably Photoshop, although I'm not sure): 16.0pt, 16px

You are free to edit and use this as long as you give credit to me, and do not claim as your own.
------------------