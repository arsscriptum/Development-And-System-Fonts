D Lyle Hand
A handwriting font based on my writing style.
Contact: typo969@gmail.com
Web: http://fonts.typo969.net

The personal, non-commercial use of my font is free.
But Donations are accepted and highly appreciated!
The use of my fonts for commercial and profit purposes is acceptable, but you must obtain my permission first.
These font files may not be modified and this readme file must be 
included with each font.

All trademarks are property of their respective owners.