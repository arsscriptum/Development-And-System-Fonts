 *********************************************************************
 *********************************************************************
                    ���`�.(*�.�(`�.� �.��)�.�*).��`�� 
                  ����*�.��.* MR.FISK FONTS *.��.�*�`��
                    ���`�.(�.��(�.�* *�.�)`�.�).��`�.�
 *********************************************************************
 ~'''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''~

                       This is MR.FISK BITMAP 2.0 
                           
                           I hope you like it.
                          use it in small sizes
                           4 points look good
                            antialiasing off.
                            just play with it.


  ----------------------------------------------------------------------------


  COPYRIGHT LAWS :

  YOU CAN USE THE FONT FOR FREE THINGS (I.E. THINGS THAT YOU DON'T EARN MONEY FROM).
  IF YOU ARE GOING TO USE THE FONT FOR COMMERCIAL THINGS (I.E. THINGS YOU EARN MONEY
  FROM) YOU'LL HAVE TO CONTACT ME ON THESE ADRESSES BECAUSE THERE IS A REGISTRATION/
  LICENSE FEE :

  homerec@undergroundstar.com
  fontex2000mg@softhome.net
  slemhinnor@yahoo.se
  advert@undergroundstar.com


  ------------------------------------------------------------------------------
